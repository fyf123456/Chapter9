package com.bytedance.ies.camerarecorddemoapp.gl;

public class Frame {

}
